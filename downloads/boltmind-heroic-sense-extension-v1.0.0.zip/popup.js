'use strict';
const POPUP_TEXT = {
  pt: {
    subtitle: 'Recomendador de missões',
    steps: ['Abra o Hero Zero no navegador e entre na sua conta.', 'O painel Heroic Sense aparece no canto da página do jogo.', 'Escolha XP/Energia ou Moeda/Energia. Se nada aparecer, clique em "Ler missões agora".'],
    safe: 'Somente leitura: não clica, não inicia missões, não gasta energia e não envia ações ao jogo.',
    risk: 'Use com moderação. Toda ferramenta para jogos online envolve risco, e o BoltMind não tem vínculo com o Hero Zero.',
    version: 'Versão',
  },
  en: {
    subtitle: 'Mission advisor',
    steps: ['Open Hero Zero in your browser and sign in.', 'The Heroic Sense panel appears in a corner of the game page.', 'Choose XP/Energy or Coins/Energy. If nothing appears, click "Read missions now".'],
    safe: 'Read-only: it never clicks, starts missions, spends energy or sends actions to the game.',
    risk: 'Use it in moderation. Any tool for online games carries risk, and BoltMind is not affiliated with Hero Zero.',
    version: 'Version',
  },
};
const lang = String(navigator.language || '').toLowerCase().startsWith('pt') ? 'pt' : 'en';
const text = POPUP_TEXT[lang];
document.documentElement.lang = lang === 'pt' ? 'pt-BR' : 'en';
document.getElementById('subtitle').textContent = text.subtitle;
document.getElementById('steps').replaceChildren(...text.steps.map(step => Object.assign(document.createElement('li'), { textContent: step })));
document.getElementById('safe').textContent = text.safe;
document.getElementById('risk').textContent = text.risk;
document.getElementById('version').textContent = `${text.version} ${chrome.runtime.getManifest().version}`;
