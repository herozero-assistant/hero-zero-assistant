// BoltMind Heroic Sense: mission store and ranking.
// Same rules as the desktop program (src/mission_advisor.py, extract_game_quests
// and rank_missions). Pure logic: no DOM, no network, no game actions.
(function (root) {
  'use strict';

  const LANGUAGES = [
    ['pt-BR', 'Português (Brasil)'], ['en', 'English'], ['de', 'Deutsch'], ['pl', 'Polski'], ['el', 'Ελληνικά'],
  ];

  // The 14 quest stages are numbered in quest_pool.
  const STAGES = {
    'pt-BR': ['Em casa em Humphreydale', 'Centro da cidade imundo', 'Centro de Granbury', 'Capitólio', 'Suíça', 'Big Crumble', 'Ilha Yoyo', 'Gamble City', 'Vale do SemSiso', 'Paris', 'Yollywood', 'Austrália', 'Yokio', 'O deserto dourado'],
    en: ['At Home in Humphreydale', 'Dirty Downtown', 'Center of Granbury', 'State Capitol', 'Switzerland', 'The Big Crumble', 'Yoyo Island', 'Gamble City', 'Sillycon Valley', 'Paris', 'Yollywood', 'Australia', 'Yokio', 'The Golden Desert'],
    de: ['Zuhause in Humphreydale', 'Dreckige Innenstadt', 'Zentrum von Granbury', 'State Capitol', 'Schweiz', 'Der Big Crumble', 'Yoyo-Insel', 'Gamble City', 'Sillycon Valley', 'Paris', 'Yollywood', 'Australien', 'Yokio', 'Die goldene Wüste'],
    pl: ['Moje Humphreydale', 'Plugawe Śródmieście', 'Centrum Granbury', 'State Capitol', 'Szwajcaria', 'Big Crumble', 'Wyspa Yoyo', 'Gamble City', 'Sillycon Valley', 'Paryż', 'Yollywood', 'Australia', 'Yokio', 'Złota Pustynia'],
    el: ['Στο σπίτι στο Χάμφρεϊντεϊλ', 'Βρόμικο κέντρο', 'Κέντρο του Γκράνμπερι', 'Κρατικό Καπιτώλιο', 'Ελβετία', 'Big Crumble', 'Νησί Γιόγιο', 'Gamble City', 'Sillycon Valley', 'Παρίσι', 'Yollywood', 'Αυστραλία', 'Yokio', 'Η χρυσή έρημος'],
  };

  // pt-BR, en, de, pl, el
  const TEXT = {
    safe: ['MODO SEGURO', 'SAFE MODE', 'SICHERER MODUS', 'TRYB BEZPIECZNY', 'ΑΣΦΑΛΗΣ ΛΕΙΤΟΥΡΓΙΑ'],
    subtitle: ['Recomendador de missões', 'Mission advisor', 'Missionsberater', 'Doradca misji', 'Σύμβουλος αποστολών'],
    top: ['TOP 5 MELHORES MISSÕES', 'TOP 5 MISSIONS', 'TOP 5 MISSIONEN', 'TOP 5 MISJI', '5 ΚΟΡΥΦΑΙΕΣ ΑΠΟΣΤΟΛΕΣ'],
    allTitle: ['TODAS AS MISSÕES', 'ALL MISSIONS', 'ALLE MISSIONEN', 'WSZYSTKIE MISJE', 'ΟΛΕΣ ΟΙ ΑΠΟΣΤΟΛΕΣ'],
    showAll: ['Ver todas', 'Show all', 'Alle anzeigen', 'Pokaż wszystkie', 'Προβολή όλων'],
    showTop: ['Ver Top 5', 'Show Top 5', 'Top 5 anzeigen', 'Pokaż Top 5', 'Προβολή Top 5'],
    coverage: ['{cities} cidades analisadas • {missions} missões disponíveis', '{cities} cities analyzed • {missions} available missions', '{cities} Städte analysiert • {missions} verfügbare Missionen', 'Przeanalizowano {cities} miast • {missions} dostępnych misji', '{cities} πόλεις αναλύθηκαν • {missions} διαθέσιμες αποστολές'],
    xpRate: ['XP/Energia', 'XP/Energy', 'XP/Energie', 'PD/Energia', 'Εμπ./Ενέργεια'],
    coinRate: ['Moeda/Energia', 'Coins/Energy', 'Münzen/Energie', 'Monety/Energia', 'Νομίσματα/Ενέργεια'],
    rank: ['TOP', 'TOP', 'RANG', 'MIEJSCE', 'ΘΕΣΗ'],
    city: ['CIDADE', 'CITY', 'STADT', 'MIASTO', 'ΠΟΛΗ'],
    mission: ['MISSÃO', 'MISSION', 'MISSION', 'MISJA', 'ΑΠΟΣΤΟΛΗ'],
    energy: ['ENERGIA', 'ENERGY', 'ENERGIE', 'ENERGIA', 'ΕΝΕΡΓΕΙΑ'],
    xp: ['XP', 'XP', 'XP', 'PD', 'XP'],
    coins: ['MOEDA', 'COINS', 'MÜNZEN', 'MONETY', 'ΝΟΜΙΣΜΑΤΑ'],
    perEnergy: ['POR ENERGIA', 'PER ENERGY', 'PRO ENERGIE', 'NA ENERGIĘ', 'ΑΝΑ ΕΝΕΡΓΕΙΑ'],
    cityNumber: ['Cidade {number}', 'City {number}', 'Stadt {number}', 'Miasto {number}', 'Πόλη {number}'],
    positionNumber: ['Posição {number}', 'Position {number}', 'Position {number}', 'Pozycja {number}', 'Θέση {number}'],
    readNow: ['Ler missões agora', 'Read missions now', 'Missionen jetzt lesen', 'Odczytaj misje teraz', 'Ανάγνωση αποστολών τώρα'],
    reading: ['Lendo as missões do jogo…', 'Reading the game missions…', 'Missionen werden gelesen…', 'Odczytywanie misji…', 'Ανάγνωση αποστολών…'],
    waiting: ['Aguardando as missões. Entre na conta; se nada aparecer, clique em "Ler missões agora".', 'Waiting for missions. Sign in; if nothing appears, click "Read missions now".', 'Warte auf Missionen. Einloggen; falls nichts erscheint, „Missionen jetzt lesen“ klicken.', 'Oczekiwanie na misje. Zaloguj się; jeśli nic się nie pojawi, kliknij „Odczytaj misje teraz”.', 'Αναμονή αποστολών. Συνδεθείτε· αν δεν εμφανιστεί τίποτα, πατήστε «Ανάγνωση αποστολών τώρα».'],
    notReady: ['O jogo ainda não terminou de carregar a conta. Aguarde e tente de novo.', 'The game has not finished loading the account yet. Wait and try again.', 'Das Spiel hat das Konto noch nicht geladen. Kurz warten und erneut versuchen.', 'Gra jeszcze nie wczytała konta. Poczekaj i spróbuj ponownie.', 'Το παιχνίδι δεν έχει φορτώσει ακόμη τον λογαριασμό. Περιμένετε και δοκιμάστε ξανά.'],
    devtoolsOpen: ['Feche o DevTools (F12) desta aba e tente de novo.', 'Close DevTools (F12) on this tab and try again.', 'DevTools (F12) in diesem Tab schließen und erneut versuchen.', 'Zamknij DevTools (F12) w tej karcie i spróbuj ponownie.', 'Κλείστε τα DevTools (F12) σε αυτή την καρτέλα και δοκιμάστε ξανά.'],
    failed: ['Não foi possível ler agora: {error}', 'Could not read now: {error}', 'Lesen nicht möglich: {error}', 'Nie udało się odczytać: {error}', 'Δεν ήταν δυνατή η ανάγνωση: {error}'],
    updated: ['Atualizado às {time}', 'Updated at {time}', 'Aktualisiert um {time}', 'Zaktualizowano o {time}', 'Ενημερώθηκε στις {time}'],
    minimize: ['Minimizar', 'Minimize', 'Minimieren', 'Minimalizuj', 'Ελαχιστοποίηση'],
    expand: ['Abrir painel', 'Open panel', 'Panel öffnen', 'Otwórz panel', 'Άνοιγμα πίνακα'],
    readOnly: ['Somente leitura: não clica, não inicia missões e não envia ações ao jogo.', 'Read-only: never clicks, starts missions or sends actions to the game.', 'Nur lesen: klickt nicht, startet keine Missionen, sendet keine Aktionen.', 'Tylko odczyt: nie klika, nie rozpoczyna misji i nie wysyła akcji do gry.', 'Μόνο ανάγνωση: δεν κάνει κλικ, δεν ξεκινά αποστολές, δεν στέλνει ενέργειες.'],
  };

  const CODES = LANGUAGES.map(([code]) => code);

  function normalizeLanguage(value) {
    const text = String(value || '').toLowerCase();
    if (text.startsWith('pt')) return 'pt-BR';
    for (const code of ['de', 'pl', 'el', 'en']) if (text.startsWith(code)) return code;
    return 'en';
  }

  function t(key, language, values) {
    const row = TEXT[key];
    const index = Math.max(0, CODES.indexOf(language));
    let text = row ? row[index] || row[1] : key;
    for (const [name, value] of Object.entries(values || {})) text = text.split(`{${name}}`).join(String(value));
    return text;
  }

  function asInt(value) {
    if (typeof value === 'boolean') return null;
    if (typeof value === 'number' && Number.isFinite(value)) return Math.trunc(value);
    if (typeof value === 'string') {
      const cleaned = value.replace(/[.,]/g, '').trim();
      if (/^\d+$/.test(cleaned)) return Number(cleaned);
    }
    return null;
  }

  function asObject(value) {
    if (typeof value === 'string') {
      try { value = JSON.parse(value); } catch { return null; }
    }
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  }

  /** quest_pool: {stage: [questId, ...]} -> Map(questId -> {stage, slot}). */
  function parsePool(pool) {
    const result = new Map();
    const value = asObject(pool);
    if (!value) return result;
    for (const [stage, ids] of Object.entries(value)) {
      if (!Array.isArray(ids)) continue;
      ids.forEach((id, index) => result.set(String(id), { stage: String(stage), slot: index + 1 }));
    }
    return result;
  }

  function stageName(stage, language) {
    const number = Number(stage);
    const names = STAGES[language] || STAGES['pt-BR'];
    if (Number.isInteger(number) && number >= 1 && number <= names.length) return names[number - 1];
    return t('cityNumber', language, { number: stage });
  }

  class MissionStore {
    constructor() {
      this.quests = new Map();
      this.pool = new Map();
      this.updatedAt = 0;
    }

    /**
     * Merge game data. A response without quest_pool keeps the previous pool;
     * quests are merged by id, so partial responses never erase known data.
     */
    ingest(data) {
      if (!data || typeof data !== 'object') return false;
      let changed = false;
      const pool = parsePool(data.pool);
      if (pool.size) { this.pool = pool; changed = true; }
      if (Array.isArray(data.quests)) {
        for (const quest of data.quests) {
          if (!quest || typeof quest !== 'object' || quest.id === undefined || quest.id === null) continue;
          this.quests.set(String(quest.id), quest);
          changed = true;
        }
      }
      if (changed) this.updatedAt = Date.now();
      return changed;
    }

    /** Available missions: in quest_pool, not finished (status 3), with energy cost and XP or coins. */
    missions() {
      const result = [];
      for (const [id, position] of this.pool) {
        const quest = this.quests.get(id);
        if (!quest || asInt(quest.status) === 3) continue;
        const rewards = asObject(quest.rewards) || {};
        const energy = asInt(quest.energy_cost);
        const xp = asInt(rewards.xp) || 0;
        const coins = asInt(rewards.coins) || 0;
        if (!energy || energy <= 0 || (xp <= 0 && coins <= 0)) continue;
        const title = typeof quest.name === 'string' && quest.name.trim() ? quest.name.trim()
          : (typeof quest.title === 'string' && quest.title.trim() ? quest.title.trim() : '');
        result.push({ id, stage: position.stage, slot: position.slot, title, energy, xp, coins });
      }
      return result;
    }
  }

  function rank(missions, criterion) {
    const primary = criterion === 'coins' ? 'coins' : 'xp';
    const secondary = primary === 'coins' ? 'xp' : 'coins';
    return [...missions].sort((a, b) =>
      (b[primary] / b.energy - a[primary] / a.energy) || (b[primary] - a[primary]) || (b[secondary] - a[secondary]));
  }

  root.BoltMindHeroicSense = { LANGUAGES, STAGES, TEXT, normalizeLanguage, t, asInt, parsePool, stageName, MissionStore, rank };
})(typeof globalThis !== 'undefined' ? globalThis : this);
