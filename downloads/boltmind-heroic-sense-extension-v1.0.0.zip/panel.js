// BoltMind Heroic Sense: panel shown on the Hero Zero page (extension world).
// Receives quest data from hook.js or from "Read missions now" and shows the
// ranking. Display only: it has no code that acts on the game.
(() => {
  'use strict';
  if (window.top !== window || window.__boltMindHeroicSensePanel) return;
  window.__boltMindHeroicSensePanel = true;

  const HS = globalThis.BoltMindHeroicSense;
  const SOURCE = 'boltmind-heroic-sense';
  const GAME_HOST = /(^|\.)herozerogame\.com$/i;
  const store = new HS.MissionStore();
  const prefs = { language: HS.normalizeLanguage(navigator.language), criterion: 'xp', showAll: false, minimized: false, pos: null };
  let status = { key: 'waiting', values: null, tone: 'info' };
  let reading = false;
  let host;
  let shadow;

  const tr = (key, values) => HS.t(key, prefs.language, values);

  function el(tag, attrs, ...children) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs || {})) {
      if (value === undefined || value === null || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'text') node.textContent = value;
      else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
      else node.setAttribute(key, value === true ? '' : value);
    }
    for (const child of children) if (child !== null && child !== undefined) node.append(child);
    return node;
  }

  function savePrefs() {
    try { chrome.storage.local.set({ heroicSensePrefs: prefs }); } catch { /* Storage unavailable. */ }
  }

  function number(value, digits = 0) {
    return Number(value).toLocaleString(prefs.language, { minimumFractionDigits: digits, maximumFractionDigits: digits });
  }

  const STYLE = `
:host{all:initial}
*{box-sizing:border-box}
.wrap{position:fixed;z-index:2147483646;font:13px/1.45 "Segoe UI",system-ui,-apple-system,Arial,sans-serif;color:#e8eaf0}
.panel{width:min(560px,calc(100vw - 24px));max-height:calc(100vh - 24px);display:flex;flex-direction:column;overflow:hidden;border:1px solid #233b5c;border-radius:16px;background:linear-gradient(170deg,#102139,#0b0d12 70%);box-shadow:0 22px 60px #000c,0 0 0 1px #ffffff08 inset}
.head{display:flex;align-items:center;gap:10px;padding:12px 12px 10px 14px;cursor:move;user-select:none;border-bottom:1px solid #1f2d44}
.head img{width:30px;height:30px}
.brand{display:flex;flex-direction:column;line-height:1.15}
.brand b{font-size:15px;font-weight:800;letter-spacing:-.2px}
.brand b span{background:linear-gradient(120deg,#42c9ef,#1676eb 55%,#28c8ba);-webkit-background-clip:text;background-clip:text;color:transparent}
.brand small{color:#9aa3b5;font-size:11.5px}
.safe{margin-left:auto;padding:3px 8px;border:1px solid #2f5a44;border-radius:99px;background:#13211a;color:#5be3a0;font-size:10px;font-weight:800;letter-spacing:.06em;white-space:nowrap}
.icon{display:grid;place-items:center;width:30px;height:30px;border:1px solid #2a3a55;border-radius:9px;background:#121a29;color:#c9cfdb;font-size:16px;cursor:pointer}
.icon:hover{border-color:#42c9ef;color:#fff}
.body{display:flex;flex-direction:column;gap:10px;padding:12px 14px 12px;overflow:auto}
.row{display:flex;flex-wrap:wrap;align-items:center;gap:8px}
.seg{display:inline-flex;padding:3px;border:1px solid #233b5c;border-radius:10px;background:#0d1a2e}
.seg button{padding:6px 11px;border:0;border-radius:7px;background:none;color:#a7b5cb;font:inherit;font-weight:700;cursor:pointer}
.seg button.on{background:linear-gradient(120deg,#42c9ef,#1676eb 55%,#28c8ba);color:#fff}
.btn{padding:7px 11px;border:1px solid #2a3a55;border-radius:9px;background:#14263f;color:#e8eaf0;font:inherit;font-weight:700;cursor:pointer}
.btn:hover{border-color:#42c9ef}
.btn.primary{border:0;background:linear-gradient(120deg,#42c9ef,#1676eb 55%,#28c8ba);color:#fff}
.btn:disabled{opacity:.6;cursor:wait}
select{margin-left:auto;padding:6px 8px;border:1px solid #2a3a55;border-radius:9px;background:#0d1a2e;color:#e8eaf0;font:inherit}
.status{padding:8px 10px;border-radius:9px;background:#14263f;color:#a7b5cb;font-size:12.5px}
.status.ok{background:#13211a;color:#9fe8c3}
.status.warn{background:#2a2312;color:#f2e2bd}
.title{color:#9aa3b5;font-size:11px;font-weight:800;letter-spacing:.08em}
.tablebox{max-height:min(46vh,420px);overflow:auto;border:1px solid #1f2d44;border-radius:11px}
table{width:100%;border-collapse:collapse;white-space:nowrap}
th{position:sticky;top:0;padding:8px;background:#12233a;color:#9aa3b5;font-size:10.5px;font-weight:800;letter-spacing:.05em;text-align:left}
td{padding:8px;border-top:1px solid #1a2840;color:#e8eaf0}
td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}
td.rate{color:#42c9ef;font-weight:800}
td.mission{max-width:150px;overflow:hidden;text-overflow:ellipsis}
td.city{max-width:170px;overflow:hidden;text-overflow:ellipsis}
.pos{display:inline-grid;place-items:center;min-width:24px;height:22px;padding:0 6px;border-radius:99px;background:#1a2d48;color:#c9cfdb;font-size:11px;font-weight:800}
tr.best td{background:#122a44}
tr.best .pos{background:linear-gradient(120deg,#42c9ef,#1676eb);color:#fff}
.foot{color:#7f8aa0;font-size:11px}
.mini{display:flex;align-items:center;gap:8px;padding:8px 14px 8px 8px;border:1px solid #233b5c;border-radius:99px;background:#0d1a2e;color:#e8eaf0;font:inherit;font-weight:800;box-shadow:0 12px 30px #000a;cursor:pointer}
.mini img{width:26px;height:26px}
.mini span{color:#42c9ef}
`;

  function position(wrap) {
    if (prefs.pos && Number.isFinite(prefs.pos.x) && Number.isFinite(prefs.pos.y)) {
      const x = Math.min(Math.max(0, prefs.pos.x), Math.max(0, innerWidth - 120));
      const y = Math.min(Math.max(0, prefs.pos.y), Math.max(0, innerHeight - 60));
      wrap.style.left = `${x}px`;
      wrap.style.top = `${y}px`;
    } else {
      wrap.style.right = '12px';
      wrap.style.bottom = '12px';
    }
  }

  function enableDrag(handle, wrap) {
    handle.addEventListener('pointerdown', event => {
      if (event.button !== 0 || event.target.closest('button,select')) return;
      const rect = wrap.getBoundingClientRect();
      const dx = event.clientX - rect.left;
      const dy = event.clientY - rect.top;
      handle.setPointerCapture(event.pointerId);
      const move = e => {
        prefs.pos = { x: Math.max(0, Math.min(e.clientX - dx, innerWidth - 80)), y: Math.max(0, Math.min(e.clientY - dy, innerHeight - 40)) };
        wrap.style.right = ''; wrap.style.bottom = '';
        wrap.style.left = `${prefs.pos.x}px`; wrap.style.top = `${prefs.pos.y}px`;
      };
      const up = () => {
        handle.removeEventListener('pointermove', move);
        handle.removeEventListener('pointerup', up);
        savePrefs();
      };
      handle.addEventListener('pointermove', move);
      handle.addEventListener('pointerup', up);
    });
  }

  function render() {
    if (!shadow) return;
    const logo = chrome.runtime.getURL('icons/icon-48.png');
    const wrap = el('div', { class: 'wrap' });
    position(wrap);
    if (prefs.minimized) {
      wrap.append(el('button', {
        class: 'mini', type: 'button', title: tr('expand'),
        onclick: () => { prefs.minimized = false; savePrefs(); render(); },
      }, el('img', { src: logo, alt: '' }), 'Heroic ', el('span', { text: 'Sense' })));
      shadow.replaceChildren(el('style', { text: STYLE }), wrap);
      return;
    }
    const head = el('div', { class: 'head' },
      el('img', { src: logo, alt: '' }),
      el('div', { class: 'brand' }, el('b', {}, 'BoltMind ', el('span', { text: 'Heroic Sense' })), el('small', { text: tr('subtitle') })),
      el('span', { class: 'safe', text: tr('safe') }),
      el('button', { class: 'icon', type: 'button', title: tr('minimize'), text: '–', onclick: () => { prefs.minimized = true; savePrefs(); render(); } }));
    enableDrag(head, wrap);

    const seg = el('div', { class: 'seg' },
      el('button', { type: 'button', class: prefs.criterion === 'xp' ? 'on' : '', text: tr('xpRate'), onclick: () => { prefs.criterion = 'xp'; savePrefs(); render(); } }),
      el('button', { type: 'button', class: prefs.criterion === 'coins' ? 'on' : '', text: tr('coinRate'), onclick: () => { prefs.criterion = 'coins'; savePrefs(); render(); } }));
    const select = el('select', { 'aria-label': 'Language', onchange: e => { prefs.language = e.target.value; savePrefs(); render(); } },
      ...HS.LANGUAGES.map(([code, label]) => el('option', { value: code, text: label })));
    select.value = prefs.language;
    const controls = el('div', { class: 'row' }, seg,
      el('button', { class: 'btn', type: 'button', text: prefs.showAll ? tr('showTop') : tr('showAll'), onclick: () => { prefs.showAll = !prefs.showAll; savePrefs(); render(); } }),
      select);
    const readButton = el('button', { class: 'btn primary', type: 'button', disabled: reading, text: reading ? tr('reading') : tr('readNow'), onclick: deepRead });

    const missions = HS.rank(store.missions(), prefs.criterion);
    const body = el('div', { class: 'body' }, controls, el('div', { class: 'row' }, readButton));
    const statusBox = el('div', { class: `status ${status.tone === 'ok' ? 'ok' : status.tone === 'warn' ? 'warn' : ''}` });
    if (missions.length) {
      const cities = new Set(missions.map(m => m.stage)).size;
      statusBox.textContent = tr('coverage', { cities, missions: missions.length })
        + (store.updatedAt ? ` • ${tr('updated', { time: new Date(store.updatedAt).toLocaleTimeString(prefs.language, { hour: '2-digit', minute: '2-digit' }) })}` : '');
      if (status.tone === 'warn') statusBox.textContent = tr(status.key, status.values);
    } else {
      statusBox.textContent = tr(status.key, status.values);
    }
    body.append(statusBox);

    if (missions.length) {
      const reward = prefs.criterion === 'coins' ? 'coins' : 'xp';
      const shown = prefs.showAll ? missions : missions.slice(0, 5);
      const table = el('table', {},
        el('thead', {}, el('tr', {},
          el('th', { text: tr('rank') }), el('th', { text: tr('city') }), el('th', { text: tr('mission') }),
          el('th', { class: 'num', text: tr('energy') }), el('th', { class: 'num', text: tr(reward === 'xp' ? 'xp' : 'coins') }),
          el('th', { class: 'num', text: tr('perEnergy') }))),
        el('tbody', {}, ...shown.map((m, i) => el('tr', { class: i === 0 ? 'best' : '' },
          el('td', {}, el('span', { class: 'pos', text: String(i + 1) })),
          el('td', { class: 'city', text: HS.stageName(m.stage, prefs.language), title: HS.stageName(m.stage, prefs.language) }),
          el('td', { class: 'mission', text: m.title || tr('positionNumber', { number: m.slot }), title: m.title || '' }),
          el('td', { class: 'num', text: number(m.energy) }),
          el('td', { class: 'num', text: number(m[reward]) }),
          el('td', { class: 'num rate', text: number(m[reward] / m.energy, 1) })))));
      body.append(el('div', { class: 'title', text: prefs.showAll ? tr('allTitle') : tr('top') }), el('div', { class: 'tablebox' }, table));
    }
    body.append(el('div', { class: 'foot', text: tr('readOnly') }));
    wrap.append(el('div', { class: 'panel' }, head, body));
    shadow.replaceChildren(el('style', { text: STYLE }), wrap);
  }

  function accept(data) {
    if (store.ingest(data)) {
      if (store.missions().length) status = { key: 'waiting', values: null, tone: 'ok' };
      render();
    }
  }

  function deepRead() {
    if (reading) return;
    reading = true;
    status = { key: 'reading', values: null, tone: 'info' };
    render();
    let answered = false;
    const finish = response => {
      if (answered) return;
      answered = true;
      reading = false;
      if (response && response.ok) {
        store.ingest({ quests: response.quests, pool: response.pool });
        status = store.missions().length ? { key: 'waiting', values: null, tone: 'ok' } : { key: 'notReady', values: null, tone: 'warn' };
      } else if (response && response.reason === 'devtools') {
        status = { key: 'devtoolsOpen', values: null, tone: 'warn' };
      } else if (response && (response.reason === 'not-ready' || response.reason === 'busy')) {
        status = { key: 'notReady', values: null, tone: 'warn' };
      } else {
        status = { key: 'failed', values: { error: (response && response.error) || '?' }, tone: 'warn' };
      }
      render();
    };
    try {
      chrome.runtime.sendMessage({ type: 'heroic-sense-deep-read' }, response => {
        if (chrome.runtime.lastError) finish({ ok: false, reason: 'error', error: chrome.runtime.lastError.message });
        else finish(response);
      });
    } catch (error) {
      finish({ ok: false, reason: 'error', error: String(error && error.message || error) });
    }
    setTimeout(() => finish({ ok: false, reason: 'error', error: 'timeout' }), 30000);
  }

  window.addEventListener('message', event => {
    const data = event.data;
    if (!data || data.source !== SOURCE || data.kind !== 'game-data') return;
    try {
      const origin = new URL(event.origin);
      if (origin.protocol !== 'https:' || !GAME_HOST.test(origin.hostname)) return;
    } catch { return; }
    accept({ quests: Array.isArray(data.quests) ? data.quests : [], pool: data.pool });
  });

  function mount() {
    if (host) return;
    if (!document.body) {
      document.addEventListener('DOMContentLoaded', mount, { once: true });
      return;
    }
    host = document.createElement('boltmind-heroic-sense');
    shadow = host.attachShadow({ mode: 'open' });
    (document.body || document.documentElement).append(host);
    render();
  }

  try {
    chrome.storage.local.get('heroicSensePrefs', result => {
      const saved = result && result.heroicSensePrefs;
      if (saved && typeof saved === 'object') {
        if (HS.LANGUAGES.some(([code]) => code === saved.language)) prefs.language = saved.language;
        if (saved.criterion === 'coins' || saved.criterion === 'xp') prefs.criterion = saved.criterion;
        prefs.showAll = Boolean(saved.showAll);
        prefs.minimized = Boolean(saved.minimized);
        if (saved.pos && typeof saved.pos === 'object') prefs.pos = saved.pos;
      }
      mount();
    });
  } catch {
    mount();
  }
  addEventListener('resize', () => { if (prefs.pos) render(); });
})();
