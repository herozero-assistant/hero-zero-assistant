// BoltMind Heroic Sense: passive observer, runs in the game page (MAIN world).
//
// It only LISTENS to responses the game already receives from request.php
// (XHR/fetch) and from WebSockets. It never sends a request, never changes a
// response, never clicks and never calls game code. From each response it keeps
// only the quest list and quest_pool, trimmed to the fields the ranking needs,
// and hands them to the extension panel through window.postMessage.
(() => {
  'use strict';
  if (window.__boltMindHeroicSenseHook) return;
  window.__boltMindHeroicSenseHook = true;

  const SOURCE = 'boltmind-heroic-sense';
  const MAX_TEXT = 15_000_000;
  const QUEST_FIELDS = ['id', 'status', 'energy_cost', 'rewards', 'name', 'title'];

  function trimQuest(quest) {
    const out = {};
    for (const key of QUEST_FIELDS) if (quest[key] !== undefined) out[key] = quest[key];
    return out;
  }

  function isQuestList(value) {
    return Array.isArray(value) && value.some(item => item && typeof item === 'object'
      && item.id !== undefined && item.energy_cost !== undefined);
  }

  function parseJson(text) {
    if (typeof text !== 'string') return undefined;
    const value = text.trim();
    if (value.length < 2 || value.length > MAX_TEXT || !/^[[{]/.test(value)) return undefined;
    try { return JSON.parse(value); } catch { return undefined; }
  }

  function collect(value, found, depth, seen) {
    if (depth > 10 || value === null || value === undefined) return;
    if (typeof value === 'string') {
      const parsed = parseJson(value);
      if (parsed !== undefined) collect(parsed, found, depth + 1, seen);
      return;
    }
    if (typeof value !== 'object' || seen.has(value)) return;
    seen.add(value);
    if (Array.isArray(value)) {
      for (const item of value) collect(item, found, depth + 1, seen);
      return;
    }
    if (isQuestList(value.quests)) {
      for (const quest of value.quests) {
        if (quest && typeof quest === 'object' && quest.id !== undefined) found.quests.push(trimQuest(quest));
      }
    }
    if (value.quest_pool !== undefined && value.quest_pool !== null) found.pool = value.quest_pool;
    for (const [key, child] of Object.entries(value)) {
      if (key === 'quests') continue;
      collect(child, found, depth + 1, seen);
    }
  }

  function publish(payload) {
    const found = { quests: [], pool: null };
    collect(payload, found, 0, new WeakSet());
    if (!found.quests.length && found.pool === null) return;
    try {
      window.top.postMessage({ source: SOURCE, kind: 'game-data', quests: found.quests, pool: found.pool }, '*');
    } catch { /* Top window unavailable: nothing to do. */ }
  }

  function readText(text) {
    if (typeof text !== 'string' || text.length > MAX_TEXT) return;
    const parsed = parseJson(text);
    if (parsed !== undefined) { publish(parsed); return; }
    // Socket.IO frames start with a packet number, e.g. 42["event","{...}"].
    const start = text.search(/[[{]/);
    if (start > 0) {
      const framed = parseJson(text.slice(start));
      if (framed !== undefined) publish(framed);
    }
  }

  function readAny(data) {
    try {
      if (typeof data === 'string') readText(data);
      else if (data instanceof ArrayBuffer) readText(new TextDecoder().decode(data));
      else if (typeof Blob !== 'undefined' && data instanceof Blob) data.text().then(readText, () => {});
      else if (data && typeof data === 'object') publish(data);
    } catch { /* Never interfere with the game. */ }
  }

  const isGameRequest = url => /request\.php/i.test(String(url || ''));

  // XMLHttpRequest: remember the URL, read the finished response.
  try {
    const open = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      try {
        if (isGameRequest(url) && !this.__boltMindHeroicSenseWatched) {
          this.__boltMindHeroicSenseWatched = true;
          this.addEventListener('loadend', () => {
            try {
              const type = this.responseType;
              if (!type || type === 'text') readAny(this.responseText);
              else readAny(this.response);
            } catch { /* Ignore unreadable responses. */ }
          });
        }
      } catch { /* Ignore. */ }
      return open.call(this, method, url, ...rest);
    };
  } catch { /* XHR unavailable. */ }

  // fetch: read a clone, the game keeps the original response untouched.
  try {
    const nativeFetch = window.fetch;
    if (typeof nativeFetch === 'function') {
      window.fetch = function (...args) {
        const result = nativeFetch.apply(this, args);
        try {
          const input = args[0];
          const url = typeof input === 'string' ? input : (input && input.url) || String(input || '');
          if (isGameRequest(url)) {
            result.then(response => response.clone().text().then(readText, () => {}), () => {});
          }
        } catch { /* Ignore. */ }
        return result;
      };
    }
  } catch { /* fetch unavailable. */ }

  // WebSocket: add a passive message listener to sockets the game opens.
  try {
    const NativeWebSocket = window.WebSocket;
    if (typeof NativeWebSocket === 'function') {
      const Watched = new Proxy(NativeWebSocket, {
        construct(Target, args, newTarget) {
          const socket = Reflect.construct(Target, args, newTarget);
          try { socket.addEventListener('message', event => readAny(event.data)); } catch { /* Ignore. */ }
          return socket;
        },
      });
      window.WebSocket = Watched;
    }
  } catch { /* WebSocket unavailable. */ }
})();
