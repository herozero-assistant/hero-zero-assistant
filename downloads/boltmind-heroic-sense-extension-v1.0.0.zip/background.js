// BoltMind Heroic Sense: "Read missions now".
//
// Same read-only method as the desktop program (src/mission_advisor.py,
// _attach_game_runtime + READ_ONLY_SNAPSHOT): attach the debugger to the game
// tab, locate the game's already loaded runtime, read the character's quests
// and quest_pool, then detach. It only reads; it never calls a game action.
'use strict';

const PROTOCOL = '1.3';
const GROUP = 'heroic_sense_read';
const GAME_HOST = /(^|\.)herozerogame\.com$/i;

const READ_ONLY_SNAPSHOT = `(() => {
  const runtime = globalThis.__hzVisualRuntime;
  const User = runtime && runtime.classes && runtime.classes['com.playata.application.data.user.User'];
  const user = User && User.get_current && User.get_current();
  const character = user && user.get_character();
  if (!character) return {ready:false};
  const questMap = character.get_quests();
  const quests = questMap && questMap.h ? Object.values(questMap.h).map(q => q._data) : [];
  return {ready:true, data:{quests:quests, character:{quest_pool:character._data.quest_pool}}};
})()`;

const ATTACH_FUNCTION = "function(classes){if(!this.application||!this.panelManager||!classes['com.playata.application.ui.ViewManager'])return false;globalThis.__hzVisualRuntime={environment:this,classes:classes};return true;}";

function send(target, method, params) {
  return chrome.debugger.sendCommand(target, method, params || {});
}

function internals(properties) {
  const map = {};
  for (const item of (properties && properties.internalProperties) || []) map[item.name] = item.value || {};
  return map;
}

async function attachGameRuntime(target) {
  const probe = await send(target, 'Runtime.evaluate', { expression: '!!globalThis.__hzVisualRuntime', returnByValue: true });
  if (probe && probe.result && probe.result.value) return true;
  for (const expression of ['document.querySelector("canvas")', 'window', 'document']) {
    const root = await send(target, 'Runtime.evaluate', { expression, returnByValue: false, objectGroup: GROUP });
    const rootId = root && root.result && root.result.objectId;
    if (!rootId) continue;
    const listeners = ((await send(target, 'DOMDebugger.getEventListeners', { objectId: rootId })) || {}).listeners || [];
    for (const listener of listeners) {
      const handler = listener.handler && listener.handler.objectId;
      if (!handler) continue;
      let inner = internals(await send(target, 'Runtime.getProperties', { objectId: handler, ownProperties: true }));
      const bound = inner['[[BoundTargetFunction]]'] && inner['[[BoundTargetFunction]]'].objectId;
      if (bound) inner = internals(await send(target, 'Runtime.getProperties', { objectId: bound, ownProperties: true }));
      const scopesId = inner['[[Scopes]]'] && inner['[[Scopes]]'].objectId;
      if (!scopesId) continue;
      const scopes = ((await send(target, 'Runtime.getProperties', { objectId: scopesId, ownProperties: true })) || {}).result || [];
      for (const scope of scopes) {
        const scopeId = scope.value && scope.value.objectId;
        if (!scopeId) continue;
        const values = ((await send(target, 'Runtime.getProperties', { objectId: scopeId, ownProperties: true })) || {}).result || [];
        const names = {};
        for (const item of values) names[item.name] = item.value || {};
        const environmentId = names.n && names.n.objectId;
        const classesId = names.g && names.g.objectId;
        if (!environmentId || !classesId) continue;
        const result = await send(target, 'Runtime.callFunctionOn', {
          objectId: environmentId, functionDeclaration: ATTACH_FUNCTION,
          arguments: [{ objectId: classesId }], returnByValue: true,
        });
        if (result && result.result && result.result.value) return true;
      }
    }
  }
  return false;
}

async function deepRead(tabId) {
  const target = { tabId };
  try {
    await chrome.debugger.attach(target, PROTOCOL);
  } catch (error) {
    const message = String((error && error.message) || error);
    return { ok: false, reason: /already attached|another debugger/i.test(message) ? 'devtools' : 'error', error: message };
  }
  try {
    const runtime = await attachGameRuntime(target);
    if (!runtime) return { ok: false, reason: 'not-ready' };
    const snapshot = await send(target, 'Runtime.evaluate', { expression: READ_ONLY_SNAPSHOT, returnByValue: true });
    const value = snapshot && snapshot.result && snapshot.result.value;
    if (!value || !value.ready || !value.data) return { ok: false, reason: 'not-ready' };
    const quests = Array.isArray(value.data.quests) ? value.data.quests.map(trimQuest) : [];
    const pool = value.data.character ? value.data.character.quest_pool : null;
    return { ok: true, quests, pool };
  } catch (error) {
    return { ok: false, reason: 'error', error: String((error && error.message) || error) };
  } finally {
    try { await send(target, 'Runtime.releaseObjectGroup', { objectGroup: GROUP }); } catch { /* Already gone. */ }
    try { await chrome.debugger.detach(target); } catch { /* Already detached. */ }
  }
}

function trimQuest(quest) {
  const out = {};
  if (!quest || typeof quest !== 'object') return out;
  for (const key of ['id', 'status', 'energy_cost', 'rewards', 'name', 'title']) if (quest[key] !== undefined) out[key] = quest[key];
  return out;
}

function isGameSender(sender) {
  try {
    return Boolean(sender && sender.tab && sender.frameId === 0 && GAME_HOST.test(new URL(sender.url).hostname)
      && new URL(sender.url).protocol === 'https:');
  } catch { return false; }
}

const running = new Set();

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== 'heroic-sense-deep-read') return false;
  if (!isGameSender(sender)) { sendResponse({ ok: false, reason: 'error', error: 'not a game tab' }); return false; }
  const tabId = sender.tab.id;
  if (running.has(tabId)) { sendResponse({ ok: false, reason: 'busy' }); return false; }
  running.add(tabId);
  deepRead(tabId).then(sendResponse, error => sendResponse({ ok: false, reason: 'error', error: String(error) }))
    .finally(() => running.delete(tabId));
  return true;
});
